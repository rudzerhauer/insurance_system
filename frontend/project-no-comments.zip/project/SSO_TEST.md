SSO test steps (client-app + admin-app)

Assumptions:
- Keycloak is running and the `insurance-realm.json` has been imported.
- Backend is configured to run on port 8082 and has OIDC client settings pointing to Keycloak.
- Frontend `client-app` dev server uses the proxy to forward `/api` and `/oauth2` to the backend.
- `admin-app` has its `proxy.conf.json` which forwards `/api` and `/oauth2` to the backend at http://localhost:8082.

Steps:
1) Start Keycloak (if not already running)
   - Example (docker):
     docker run -p 8080:8080 -e KEYCLOAK_ADMIN=admin -e KEYCLOAK_ADMIN_PASSWORD=admin quay.io/keycloak/keycloak:21.1.1 start-dev --import-realm
   - Make sure `insurance-realm.json` is placed into the Keycloak import folder or import via admin UI.

2) Start backend (port 8082)
   - cd to backend project
   - ./mvnw spring-boot:run
   - Confirm backend starts and `/.well-known/openid-configuration` is reachable at http://localhost:8080/realms/insurance-realm/.well-known/openid-configuration

3) Start client-app dev server with proxy
   - cd client-app
   - npm install (if needed)
   - npm run start:proxy
   - Open http://localhost:4201 (or the port your client-app uses)

4) Start admin-app dev server with proxy
   - cd admin-app
   - npm install
   - npm run start:proxy
   - Open http://localhost:4202

5) Initiate SSO from either app
   - In client-app or admin-app click the Login/SSO button (or navigate to `/oauth2/authorization/keycloak` via top-level navigation).
   - This should redirect to Keycloak, prompt for credentials, then redirect back to the backend's redirect URI.
   - The backend will exchange the code and set HttpOnly JWT cookies (ACCESS_TOKEN/REFRESH_TOKEN) for the SPA (same-origin thanks to the proxy).

6) Verify authenticated endpoints
   - In the browser (after redirect back to the SPA) call `/api/auth/me` (or click a UI button) to confirm user info is returned.
   - In admin-app, open Users page (http://localhost:4202) and confirm the list loads from `/api/admin/users`.

Troubleshooting:
- If cookies are not present, confirm the dev proxy is forwarding requests with the same host and that the backend sets cookie path and SameSite appropriately.
- If Keycloak 404 or discovery errors occur, re-import the realm and verify the issuer URL in backend properties matches Keycloak (http://localhost:8080/realms/insurance-realm).

Notes and next steps:
- For production you should register a second Keycloak client for the admin-app and use proper redirect URIs, HTTPS, and stricter cookie settings.
- The backend admin endpoints should be protected with a role check (e.g., require ROLE_ADMIN). See SecurityConfig to add `.requestMatchers("/api/admin/**").hasRole("ADMIN")`.
