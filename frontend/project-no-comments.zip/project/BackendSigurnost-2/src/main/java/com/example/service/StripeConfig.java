package com.example.service;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.stripe.*;

import jakarta.annotation.PostConstruct;
@Configuration   // postavlja parametre za aplikaciju
public class StripeConfig {

	
	@Value("${stripe.secret-key}")
	private String secretKey;
	
	
	
	@PostConstruct
	public void init() { //izvrsava se samo jednom tako da se uvijek zna vrijednost .apiKey
		Stripe.apiKey = secretKey;
	}
}
