package com.example.service;

import java.security.SecureRandom;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.User;
import com.example.repository.UserRepo;

@Service
public class TwoFactorAuthService {

	@Autowired
	private UserRepo userRepo;
	@Autowired
	private Email email;
	
	public String generateAndSendCode(User user) {
		String code = String.format("%06d", new SecureRandom().nextInt(99999));
		user.setVerifactionCode(code);
		user.setVerified(false);
		userRepo.save(user);
		email.sendVerificationCode(user.getEmail(), code);
		return code;
	}
	
	public boolean verifyCode(String username, String code) {
		User user = userRepo.findByUsername(username);
		if(user != null && code.equals(user.getCode())) {
			user.setVerified(true);
			user.setVerifactionCode(null);
			userRepo.save(user);
			return true;
		}
		return false;
	}
	
	
	
}
