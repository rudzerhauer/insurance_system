package com.example.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Policy;
import com.example.model.PolicyType;
import com.example.model.User;
import com.example.repository.PolicyRepo;
import com.example.repository.PolicyTypeRepo;

@RestController
@RequestMapping("/api/policies")
public class PolicyController {

	
	private final PolicyRepo repo;
	
	private final PolicyTypeRepo policyTypeRepo;
	
	
	public PolicyController(PolicyRepo repo, PolicyTypeRepo policyTypeRepo) {
		this.repo = repo;
		this.policyTypeRepo = policyTypeRepo;
	}
	
	@GetMapping
	public List<Policy> getAllPolicies() {
		return repo.findAll();
	}
	@GetMapping("/types")
	public List<PolicyType> getPolicyTypes() {
		return policyTypeRepo.findAll();
	}
	
	@GetMapping("/my")
	public List<Policy> getMyPolicies(Authentication auth) {
		return repo.findByUserUsername(auth.getName());
	}
	@PostMapping("/buy/{id}")
	public ResponseEntity<?> buyPolicy(@PathVariable long id, Authentication auth) {
		Optional<Policy> opt = repo.findById(id);
		if(opt.isEmpty()) {
			return ResponseEntity.notFound().build();
		}
		Policy p = opt.get();
		p.setUser(new User(auth.getName()));
		repo.save(p);
		return ResponseEntity.ok("Policy bough successfully");
		
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<?> cancelPolicy(@PathVariable Long id, Authentication auth) {
		Optional<Policy> opt = repo.findById(id);
		if(opt.isEmpty()) {
			return ResponseEntity.notFound().build();
		}
		
		Policy p = opt.get();
		if (p.getUser() == null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Policy is not owned and cannot be cancelled");
		}
		if(!p.getUser().getUsername().equals(auth.getName())) {
			return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
		}
		repo.delete(p);
		return ResponseEntity.ok("Policy canceled");
	}
	
}
